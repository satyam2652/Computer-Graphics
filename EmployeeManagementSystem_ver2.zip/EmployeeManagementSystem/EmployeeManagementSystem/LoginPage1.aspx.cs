﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EBAL;
using EBE;
using EmployeeLogin;

namespace EmployeeManagementSystem
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        EBAL.EmployeeBALCls employeeCredentials =new EBAL.EmployeeBALCls();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btn_Login_Click(object sender, EventArgs e)
        {
            try
            {
                EBE.EmployeeLoginRequestBE request = new EBE.EmployeeLoginRequestBE();
                request.UserName = txt_LoginName.Text.Trim();
                request.Password = txt_Password.Text.Trim();
                var response = employeeCredentials.LoginCredential(request);

                if (response.IsSuccess)
                {
                    Response.Redirect("PageLifeCycle.aspx");
                }
                else
                {
                    lblMsg.Text = "error";
                }
            }
            catch (Exception)
            {
                throw;
                //LogManager.Log(ex);
            }
            
        /*    try
            {
                lblExceptions.Text += "before throw";
                throw new DivideByZeroException();
            }
            catch (DivideByZeroException)
            {
                lblExceptions.Text += "Exception caught";
            }
            */
            string name, pwd;
            name = "satyam";
            pwd = "admin";

            //Hardcode some values for Textboxes
            txt_LoginName.Text = "satyam";
            txt_Password.Text = "admin";

            if (txt_LoginName.Text == name && txt_Password.Text == pwd && ChkLogin.Checked == true)
            {
                lblName.Text = "success!";
                lblMsg.Text = "Welcome " + txt_LoginName.Text;
            }
            else
            {
                lblName.Text = "Error!";
                lblMsg.Text = "please try agian";
            }

            Session["Data_to_pass"] = txt_LoginName.Text;
            Session.Timeout = 1;
           // Response.Redirect("Registration.aspx");

            Application["greetings"] = "Welcome to ODL Mr. ";
            
            lblGreetings.Text=Application["greetings"].ToString()+ (string) Session["Data_to_pass"];
           //2. Response.Redirect("Registration.aspx?PassVal=" + txt_LoginName.Text);
        }

        protected void btnClearSession_Click(object sender, EventArgs e)
        {
            Session.Remove("Data_to_pass");

            
                /* if(Session["Data_to_pass"] == null)
             {
                 Response.Redirect("Registration.aspx");
             }*/

        }
      

        

    }
}