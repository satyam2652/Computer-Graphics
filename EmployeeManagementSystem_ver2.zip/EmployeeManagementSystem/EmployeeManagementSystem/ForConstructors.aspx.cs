﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmployeeManagementSystem
{
    public partial class WebFormDay3 : System.Web.UI.Page
    {

        public string HotelName { get; set; }

        public int FoodPrice { get; set; }

        
        public WebFormDay3(string name,int price)       //parametrized constructor
        {
            this.HotelName="taj";
            this.FoodPrice= 555; 
        }
     
        public WebFormDay3()            //Default Constuctor
        {
            this.HotelName = "Marriots";
            this.FoodPrice = 2000;
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            WebFormDay3 e1 = new WebFormDay3();

            WebFormDay3 e2 = new WebFormDay3("taj", 100); //Parametrized constructor

            //  lblOPHotelName.Text = "Hotel Name: " + e1.HotelName + "<br>" + "Food Price: " + e1.FoodPrice;

            lblOPHotelName.Text = "Hotel Name: " + e2.HotelName + "<br>" + "Food Price: " + e2.FoodPrice;

            /*
                for(int i=0;i<7;i++)
                    lblDisplayDay.Text += Enum.GetName(typeof(WeekDays),i);     //my code works
           */

           //   lblDisplayDay.Text=Enum.GetName(typeof(WeekDays),4);

            /*
                foreach (string strWeekdays in Enum.GetNames(typeof(WeekDays)))
                {
                   lblDisplayDay.Text = lblDisplayDay.Text + "\n Day=" + strWeekdays.ToString();    // to display all values
                }
             */
        }

        enum WeekDays
        {
            Mon, Tue, Wed, Thu, Fri, Sat, Sun
        }

        protected void btnGetPosition_Click(object sender, EventArgs e)
        {
            
            string day = txtDay.Text;
           
            for (int i = 0; i < 7; i++) { 
                if(Enum.GetName(typeof(WeekDays),i)==day){
                    i++;
                    lblPosition.Text = i.ToString();
                }
            }

            /*
           int i = 0;
           foreach (string strWeekdays in Enum.GetNames(typeof(WeekDays)))
           {
               while (day != strWeekdays)
                   i++;
               lblPosition.Text = i.ToString();
           }
           */
        }



    }
}