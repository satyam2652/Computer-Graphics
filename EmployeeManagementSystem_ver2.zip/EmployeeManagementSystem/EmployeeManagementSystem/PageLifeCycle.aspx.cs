﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmployeeManagementSystem
{
    public partial class PageLifeCycle : System.Web.UI.Page
    {
       
        protected void Page_PreInit(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "PreInit";
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "Init";
        }
        protected void Page_InitComplete(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "InitComplete";
        }
        protected override void OnPreLoad(EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "PreLoad";
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "Loading";
        }
       
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "Loading Complete";
        }
        protected override void OnPreRender(EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "PreRender";
        }
        protected void OnSavedStateComplete(EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "Save StateComplete";
        }
        protected void Page_UnLoad(object sender, EventArgs e)
        {
            lblPgLife.Text = lblPgLife.Text + "<br/>" + "Unload";
        }
       

        //int width;
       // int num;
      
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        protected void btnReverseStr_Click(object sender, EventArgs e)
        {
            string ipString = txtIpString.Text;

            string reverseString= string.Empty;
            char[] array = ipString.ToCharArray();

            for (int i = array.Length - 1; i > -1; i--)
            {
                reverseString += array[i];
            }
            lblOp.Text = reverseString;
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            int no1 = int.Parse(TextBox1.Text);
            int no2 = int.Parse(TextBox2.Text);
            if (no1 % 2 == 0 && no2 % 2 == 0)
                lblEvenOdd.Text = "both are even numbers";
            else if (no1 % 2 != 0 && no2 % 2 == 0)
                lblEvenOdd.Text = "number 1 is odd and number 2 is even";
            else
                lblEvenOdd.Text = "One number is odd and one is even";
        }

        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            int width = int.Parse(txtWidth.Text);
            for (int i = 0; i <= width; i++)
            {
                for (int j = width-1; j >= i; j--)
                {
                    Response.Write("*");
                }
                Response.Write("<br>");
            }
        }
        
    }
}