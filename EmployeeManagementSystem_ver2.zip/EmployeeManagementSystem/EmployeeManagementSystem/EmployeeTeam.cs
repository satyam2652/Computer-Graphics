﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeManagementSystem
{
    public class EmployeeTeam
    {
        public int EmpID { get; set; }
        public string GroupName { get; set; }
       
    }
}