﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace inHeritance
{
    public class MyException: Exception
    {
        public MyException(string Message) : base(Message) { }
        public MyException() { }
        public MyException(string Message, Exception inner) : base(Message, inner) { }

    }
}