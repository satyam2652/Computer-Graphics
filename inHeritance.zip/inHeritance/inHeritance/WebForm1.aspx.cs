﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using inHeritanceLogging;

namespace inHeritance
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {/*
            int a = 50;
            int b = 10;
            int k = a / b;
            try
            {
                if (k < 10)
                {
                    throw new MyException("<br/>value of k is less than 10");
                }
            }
            catch (MyException e1)
            {
                lblException.Text = "<br/>caught My Exception";
                lblException.Text += e1.Message;
                LogManager.Log(e1);
            }*/
            /*
            int[] nums = new int[15];
            try
            {
                lblException.Text = "<br/>Before exception";
                //generate an index out-of-bounds exception
                for (int i = 0; i < 10; i++)
                {
                    nums[i] = i;
                    lblException.Text += "<br/>Num[" + i + "] --> " + nums[i];
                    //lblException.Text += "$ Num[{i}] = {nums[i]} ";
                }
                lblException.Text += "<br/>This won't happen again";
            }
            catch(IndexOutOfRangeException)
            {
                //catch the exception
                lblException.Text += "<br/>Index Out Of Range";
            }
            lblException.Text += "<br/>After catch statement";
            */
            
            int[] numerator = { 4,8,16,32,64,128,256,512 };
            int[] denominator = { 2, 0, 4, 0, 8 };
            for (int i = 0; i < numerator.Length; i++)
            {
                try
                {
                    double temp = numerator[i] / denominator[i];

                    lblException.Text += "<br/>" + temp;
                }
                catch (DivideByZeroException ex)
                {
                    LogManager.Log(ex);

                    //lblException.Text += "<br>DivideByZeroException";
                }
                catch (IndexOutOfRangeException ex)
                {
                    LogManager.Log(ex);
                   // lblException.Text += "<br>IndexOutOfRangeException";
                }
                finally
                {
                    //lblException.Text += "<br/>Finally Blocked";
                }
            }
            /*
            try
            {
                lblException.Text += "before throw";
                throw new DivideByZeroException();
            }
            catch (DivideByZeroException)
            {
                lblException.Text += "Exception caught";
            }*/



        }


        /*
        interface Area
        {
            void calcArea(double radius);
        }
        interface volume
        {
            void calcVolume(int side);
        }
        public class circle:Area{
            public double calcArea(double radius)
            {
                double pi = 3.14;
                double result;
                result = pi * radius * radius;
                lblArea = new System.Web.UI.WebControls.Label();
                lblArea.Text = result.ToString();
                return result;
            }
            public Label lblArea { get; set; }
            }
        */

        protected void Button1_Click(object sender, EventArgs e)
        {
            Salary e1 = new Salary("satyam",10000,50);

            lblSalary.Text = "<br/>" + e1.basicSalary(); 
            
            lblSalary.Text += "<br/>" + e1.ComputeGrossSalary();
        }

    }
    
}
