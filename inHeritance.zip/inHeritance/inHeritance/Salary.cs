﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace inHeritance
{
    public class Salary: Employee, GrossIncome
        {
            
            double HRA = 500;
            
            public Salary(string name,double basicSal,double h): base(name, basicSal)
            {
                name="admin";
                basicSal=8000;
                HRA=h;
            }

            public int TA()
            {
                int ta=100;
                return ta;
            }

            public int DA()
            {
                int da = 200;
                return da;
            }

            public string ComputeGrossSalary()
            {
                double Gross_sal = BasicSal + TA() + DA() + HRA;
                
                string info2 = "Gross Salary= " +Gross_sal;

                return info2;
            }
         
        }
}