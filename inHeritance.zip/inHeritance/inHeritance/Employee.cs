﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace inHeritance
{
    public class Employee
    {
             string Name;
             protected double BasicSal;

             public Employee(string EmpName, double EmpBasicSalary)
             {
                 Name = EmpName;
                 BasicSal = EmpBasicSalary;
             }

            public string basicSalary()
            {

                string info1 = "Name=" + Name + "<br/>Basic Salary=" + BasicSal;
                return info1;
            }
    }
}