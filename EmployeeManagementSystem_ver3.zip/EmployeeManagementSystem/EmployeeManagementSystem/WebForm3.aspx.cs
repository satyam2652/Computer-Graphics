﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeLogin;

namespace EmployeeManagementSystem
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int[] numerator = { 4, 8, 16, 32, 64, 128, 256, 512 };
            int[] denominator = { 2, 0, 4, 0, 8 };
            for (int i = 0; i < numerator.Length; i++)
            {
                try
                {
                    double temp = numerator[i] / denominator[i];

                    //lblException.Text += "<br/>" + temp;
                }
                catch (DivideByZeroException ex)
                {
                    LogManager.Log(ex);
                    // lblException.Text += "<br>DivideByZeroException";
                }
                catch (IndexOutOfRangeException ex)
                {
                    LogManager.Log(ex);
                    // lblException.Text += "<br>IndexOutOfRangeException";
                }
                finally
                {

                    // lblException.Text += "<br/>Finally Blocked";
                }
            }
        }
    }
}