﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EBAL;
using EBE;

namespace EmployeeManagementSystem
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        EBAL.EmployeeLoginBAL employeeRegDetails = new EBAL.EmployeeLoginBAL();

        int num, width;
        protected void Page_Load(object sender, EventArgs e)
        {
            Application["greetings"] = "Welcome to ODL Mr. ";
            //if (!IsPostBack)
            {
                dplStates.Items.Add("Delhi");
                dplStates.Items.Add("Rajasthan");
            }
            //lblData.Text = Session["Data_to_pass"].ToString();
           //2. String PassedValue=Request.QueryString["PassVal"];
            //2. lblData.Text = PassedValue;
            DateTime? day2=null;

            if (day2 != null)
                return;
            else
            {
                day2 = DateTime.Now;
                lblDate.Text = day2.ToString();
            }

            object o = day2;
            DateTime? dt2 = o as DateTime?;

            int? j = null;
            int? k = 30;
            int res1 = j ?? 0;
            int res2 = k ?? 0;
            lblTempResult.Text = "res1="+res1+ " res2=" +res2;
        }

        protected void BtnNewRegistration_Click(object sender, EventArgs e)
        {
           
            if (txtNewName.Text == null)
                return;
            
            if(txtNewPassword.Text ==null)
                return;
            
            if (txtNewCnfPassword.Text == null)
                return;

            if (rdoMale.Checked == true)
            { 
                rdoFemale.Checked = false;
            }
            else
            rdoFemale.Checked = true;

            if (Calendar1.SelectedDate.ToString() == null)
                return;

            if (dplStates.SelectedValue.ToString() == "Goa")
                return;

            if (txtContactNo.Text == null)
                return;

            try
            {
                EBE.EmployeeRegistrationRequestBE request = new EBE.EmployeeRegistrationRequestBE();
                request.UserName = txtNewName.Text.Trim();
                request.Password = txtNewPassword.Text.Trim();
                request.Sex = rdoMale.Checked.ToString();
                request.State = dplStates.SelectedValue.ToString();
                request.ContactNo = txtContactNo.Text.Trim();

                var response = employeeRegDetails.RegistrationStatusResponse(request);

                if (response.IsSuccess)
                {
                    Response.Redirect("PageLifeCycle.aspx");
                }
                else
                {
                    lblTempResult.Text = "error";
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        
    }
}