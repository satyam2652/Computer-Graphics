﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmployeeManagementSystem
{
    public partial class GenericCollection : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            List<string> listdata1 = new List<string>();
            listdata1.Add("c#");
            listdata1.Add("c++"); 
            listdata1.Add("Python"); 


            foreach (string lang in listdata1)
            {
                Label1.Text += "<br/>" + lang.ToString();
            }
            

            List<int> listdata = new List<int>();
            for (int i = 0; i < 11; i++)
                listdata.Add(i);

            int Addition = 0;

            Addition = listdata.Sum();

            foreach (int lang in listdata)
            {
                Label1.Text += "<br/>" +lang.ToString();
            }
            Label1.Text += "<br/>Sum= " + Addition;
        }


        public int EmpID { get; set; }
        public string EmpName { get; set; }


        protected void Button2_Click(object sender, EventArgs e)
        {
            IList<GenericCollection> empData = new List<GenericCollection>()
            {
                new GenericCollection()
                {EmpID=101,EmpName="satyam"},
                new GenericCollection()
                {EmpID=102,EmpName="Pranay"},
                new GenericCollection()
                {EmpID=103,EmpName="Shraddha"},
                new GenericCollection()
                {EmpID=104,EmpName="Sabella"},
                new GenericCollection()
                {EmpID=105,EmpName="Mithila"},
                new GenericCollection()
                {EmpID=106,EmpName="Pradnya"}
            };
            /*
            foreach (GenericCollection info in empData)
            {
                Label1.Text += "<br/>ID: " + info.EmpID +"Name:"+ info.EmpName;
            }
            */
            IList<EmployeeTeam> EmpTeam = new List<EmployeeTeam>()
            {
                new EmployeeTeam()
                {EmpID=101,GroupName="TechnicalTraineeA"},
                new EmployeeTeam()
                {EmpID=102,GroupName="TechnicalTraineeB"},
                new EmployeeTeam()
                {EmpID=103,GroupName="TechnicalTraineeC"}
            };

            var groupJoin = from emp in EmpTeam
                            join s in empData
                            on emp.EmpID equals s.EmpID
                            into DevGroup
                            select new
                            {
                                Employees = DevGroup,
                                EmployeeGroup = emp.GroupName
                            };
            int z=0;
            foreach (var item in groupJoin)
            {
                z++;
                Label3.Text += "<br/>Emp Group: " + z +" : "+ item.EmployeeGroup;
                foreach (var emp in item.Employees)
                {
                    z++;
                    Label3.Text += "<br/>Emp Name: " + z +" : "+emp.EmpID+ " " +emp.EmpName;
                }
            }
            var languageparam = new Dictionary<string, string>();
            languageparam.Add("c++", "object-oriented");
            languageparam.Add("c#", "professional");
            languageparam.Add("F#", "Functional-oriented");

            foreach (KeyValuePair<string, string> temp in languageparam)
            {
                Label4.Text += "<br/> " + temp.Value + "<br/>" + temp.Key; 
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            List<int> listdata = new List<int>();
            for (int i = 0; i < 10; i++)
            {
                listdata.Add(i);
            }

           // List<int>.Enumerator ex = listdata.GetEnumerator();
           // Write(ex);

            List<string> listdata1 = new List<string>();
            listdata1.Add("c#");
            listdata1.Add("c++");
            listdata1.Add("Python"); 

            List<string>.Enumerator ex2 = listdata1.GetEnumerator();
            Write(ex2);
        }
        void Write(IEnumerator<string> e)
        {
            while (e.MoveNext())
            {
                string value = e.Current;
                Label5.Text += "<br>" + value;
            }
        }






    }
}