﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EBE;
using EDAL;

namespace EBAL
{
    class EmployeeRegistrationBAL
    {
        EmployeeDAL EmployeeRegistration = new EmployeeDAL();
/*
        public EmployeeLoginResponseBE LoginCredential(EmployeeLoginRequestBE request)
        {


            EmployeeLoginResponseBE response = null;
            try
            {
                //using(EmployeeLoginDAL EmployeeLogin = new EmployeeLoginDAL())
                // {
                response = EmployeeLogin.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);     //>=1
                // }
            }
            catch (Exception ex)
            {
                if (response == null)
                    response = new EmployeeLoginResponseBE();

                response.ErrorCode = 100;
                response.ErrorMessage = ex.Message;
            }
            return response;
        }*/
    }
}
