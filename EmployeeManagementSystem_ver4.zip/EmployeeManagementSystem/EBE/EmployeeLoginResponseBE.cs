﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EBE
{
    public class EmployeeLoginResponseBE : BaseResponse
    {
         public string Username{ get; set; }
         public int Status{ get; set; }
    }
}
