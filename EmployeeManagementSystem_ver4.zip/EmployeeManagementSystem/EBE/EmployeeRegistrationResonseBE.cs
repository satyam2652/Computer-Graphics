﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EBE
{
    public class EmployeeRegistrationResonseBE: BaseResponse
    {
        public string UserName { get; set; }
        public int Status { get; set; }
    }
}
