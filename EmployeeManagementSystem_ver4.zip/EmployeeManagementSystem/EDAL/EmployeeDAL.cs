﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EBE;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace EDAL
{
    public class EmployeeDAL
    {
        public static string conn = ConfigurationManager.ConnectionStrings["Quest2ConnectionString"].ConnectionString;

        SqlConnection connect = new SqlConnection(conn);

        public EmployeeLoginResponseBE LoginCredential(EmployeeLoginRequestBE request)
        {
            EmployeeLoginResponseBE response = new EmployeeLoginResponseBE();
            try
            {
                SqlCommand cmd = new SqlCommand("usp_Login", connect);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserName", request.UserName);
                cmd.Parameters.AddWithValue("@Password", request.Password);

                SqlParameter userIDParameter = cmd.Parameters.Add("@User_id", SqlDbType.Int);
                userIDParameter.Direction = ParameterDirection.Output;

                SqlParameter statusParameter = cmd.Parameters.Add("@status", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                connect.Open();
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@status"].Value);
                connect.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }

        /*
        public EmployeeRegistrationResponseBE LoginCredential(EmployeeLoginRequestBE request)
        {
            EmployeeLoginResponseBE response = new EmployeeLoginResponseBE();
            try
            {
                SqlCommand cmd = new SqlCommand("usp_Login", connect);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserName", request.UserName);
                cmd.Parameters.AddWithValue("@Password", request.Password);

                SqlParameter userIDParameter = cmd.Parameters.Add("@User_id", SqlDbType.Int);
                userIDParameter.Direction = ParameterDirection.Output;

                SqlParameter statusParameter = cmd.Parameters.Add("@status", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;

                connect.Open();
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@status"].Value);
                connect.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return response;
        }*/
    }
}
