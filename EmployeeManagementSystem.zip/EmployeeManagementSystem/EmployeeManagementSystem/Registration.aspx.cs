﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmployeeManagementSystem
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        int num, width;
        protected void Page_Load(object sender, EventArgs e)
        {
            Application["greetings"] = "Welcome to ODL Mr. ";
            //if (!IsPostBack)
            {
                dplStates.Items.Add("Delhi");
                dplStates.Items.Add("Rajasthan");
            }
            //lblData.Text = Session["Data_to_pass"].ToString();
           //2. String PassedValue=Request.QueryString["PassVal"];
            //2. lblData.Text = PassedValue;
            DateTime? day2=null;



            if (day2 != null)
                return;
            else
            {
                day2 = DateTime.Now;
                lblDate.Text = day2.ToString();
            }

            object o = day2;
            DateTime? dt2 = o as DateTime?;

            int? j = null;
            int? k = 30;
            int res1 = j ?? 0;
            int res2 = k ?? 0;
            lblTempResult.Text = "res1="+res1+ " res2=" +res2;

            //string temp;
            //lblIp.Text = "ODL";

           // for (int i = lblIp.Text.Length; i > 0; i--)
            //    temp += lblIp.Text;




        }

        protected void BtnNewRegistration_Click(object sender, EventArgs e)
        {
           
            if (txtNewName.Text == null)
                return;
            if(txtNewPassword.Text ==null)
                return;
            if (txtNewCnfPassword.Text == null)
                return;
            if (rdoMale.Checked == true)
            { 
                rdoFemale.Checked=false;
            }else
            rdoFemale.Checked = true;

        }

        protected void btnIp_Click(object sender, EventArgs e)
        {

           
        }
    }
}